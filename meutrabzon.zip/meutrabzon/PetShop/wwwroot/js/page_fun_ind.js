var login = {

    init: function () {

        y.onclick("btnLogar", login.btnLogarOnClick);

    },

    btnLogarOnClick: function() { 

        var dados = {
            usuario: y.byId("usuario").value,
            senha: y.byId("senha").value
        }

        y.ajax(dados, "/Funcionario/Logar", "POST", function (lit) { 


            if (lit.logado) {                       
                    document.location.href = lit.url;                        
            }
            else { 

                dialog.alertError("Usuário inválido.");

            }

        }, function () {
            dialog.alertError("Deu erro....");
         })

    }

};

document.addEventListener("DOMContentLoaded", function () { 

    login.init();

});